function AddTask() {
  <h1>Add Task</h1>;
}

export default AddTask;
